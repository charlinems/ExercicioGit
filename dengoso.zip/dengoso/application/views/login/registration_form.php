<!doctype html>
<html lang="pt_BR">
<?php
if (isset($this->session->userdata['logged_in'])) {
  header("location: http://localhost/dengoso/index.php/login/user_login_process");
}
?>
  <head>
    <title>Registro de usuário</title>
  </head>
  <body>
    <div id="main">
      <div id="login">
        <h2>Registration Form</h2>
        <hr/>
<?php
echo "<div id='error_msg'>";
echo validation_errors();
echo "</div>";
echo form_open('user_auth/new_user_registration');
echo form_label('Nome de Usuário: ');
echo"<br/>";
echo form_input('username');
echo "<div id='error_msg'>";
if (isset($message_display)) {
  echo $message_display;
}
echo "</div>";
echo "<br/>";
echo form_label('E-mail: ');
echo "<br/>";
$data = array(
  'type' => 'email',
  'name' => 'email'
);
echo form_input($data);
echo "<br/>";
echo "<br/>";
echo form_label('Senha: ');
echo "<br/>";
echo form_password('password');
echo "<br/>";
echo "<br/>";
echo form_submit('submit', 'Cadastrar');
echo form_close();
?>
  <a href="<?php echo base_url() ?> ">Para entrar, clique aqui.</a>
      </div>
    </div>
  </body>
</html>
