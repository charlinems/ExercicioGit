<!doctype html>
<html lang="pt_BR">
<?php
  if (isset($this->session->userdata['logged_in'])) {
    header("location: ".base_url("dashboard"));
  }
?>
<?php
if (isset($logout_message)) {
  echo "<div class=\"alert alert-info\" role=\"alert\">";
  echo $logout_message;
  echo "</div>";
}
if (isset($message_display)) {
  echo "<div class=\"alert alert-info\" role=\"alert\">";
  echo $message_display;
  echo "</div>";
}
?>
<div id="main" class="container mt-5 card bg-light">
  <div class="row">
    <div class="col-sm-10 offset-sm-1 text-center">
      <h2 class="display-5">Bem Vindo ao Dengoso 1.0</h2>
      <div class="info-form">
        <?php echo form_open('user_auth/user_login_process'); ?>
        <?php
          echo "<div id='error_msg'>";
          if (isset($error_message)) {
            echo $error_message;
          }
          echo validation_errors();
          echo "</div>";
        ?>
        <div class="form-group">
          <label for="email" class="sr-only">E-mail :</label>
          <input type="text" name="email" id="email" placeholder="E-mail" class="form-control"/><br /><br />
          <label for="password" class="sr-only">Senha :</label>
          <input type="password" name="password" id="password" placeholder="**********" class="form-control"/><br/><br />
          <input type="submit" value=" Entrar " name="submit" class="btn btn-primary"/><br />
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
</div>

</html>
