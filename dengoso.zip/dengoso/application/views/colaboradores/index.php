<?php
if (!isset($this->session->userdata['logged_in'])) {
  header("location: ".base_url());
}
?>
<div class="container-fluid">
	<h2 class="text-center">Colaboradores</h2>
</div>
  
