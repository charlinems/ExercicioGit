<!doctype html>
<html lang="pt_BR">
    <head>
        <title>Listar Equipamentos</title>
		<link rel="stylesheet" href="css/bootstrap.css"><link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/bootstrap.min.css");?>">
    </head>
    <body>
        <h3>Lista de Equipamentos</h3>
        <?php foreach ($equipamentos as $equipamento) : ?>
            <p><strong>Inventário:</strong> <?php echo $equipamento->inventario ?></p>
            <p><strong>Nome:</strong> <?php echo $equipamento->nome ?></p>
            <p><strong>Descrição:</strong> <?php echo $equipamento->descricao ?></p>
            <hr />
        <?php endforeach; ?>
    </body>
</html>
	
	
	
	<!--<table class="table">
	
	
		<tr>
		<th>INVENTÁRIO</th>
		<th>NOME</th>
		<th>DESCRIÇÃO</th>
		</tr>
		-->


