<html lang="pt_BR">
<?php
if (isset($this->session->userdata['logged_in'])) {
 
}
?>

<head>
    <title>	EQUIPAMENTOS </title>
	<link rel="stylesheet" href="css/bootstrap.css"><link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/bootstrap.min.css");?>">
</head>

<body>


	
        <h1>Cadastro de Equipamentos</h>
        <?php echo (isset($msg) ? $msg : '') ?>
        <form method="post">
            <input type="hidden" name="acao" value="inserir" />
			<p>Inventário: <br /><input type="number" name="inventario" /></p>
            <p>Equipamento: <br /><input type="text" name="nome" /></p>
            <p>Descrição: <br /><input type="text" name="valor" /></p>
            <p><input type="submit" value="Cadastrar" /></p>
        </form>
    

	
	
	
	



</body>
  