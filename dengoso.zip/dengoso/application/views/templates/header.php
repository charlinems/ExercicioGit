<!doctype html>
<html lang="pt_BR">
<head>
  <title><?php echo $appname; ?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/bootstrap.min.css");?>">
</head>
  <body>
    <div id="topheader">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand" href="<?php echo base_url();?>">Dengoso 1.0</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Ativar navegação">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav mr-auto">
<?php
  if(isset($this->session->userdata['logged_in'])) {
?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url("dashboard");?>">Dashboard</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url("localidades");?>">Localidades</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url("colaboradores");?>">Colaboradores</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url("equipes");?>">Equipes</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url("equipamentos");?>">Equipamentos</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url("atendimentos");?>">Atendimentos</a>
          </li>
<?php 
}
?>
        </ul>
<?php
  if(isset($this->session->userdata['logged_in'])) {
    $username = $this->session->userdata['logged_in']['username'];
?>
  <span class="navbar-text">Usuário: <?php echo $username; ?></span>
  &nbsp;&nbsp;
  <a class="btn btn-primary" href="<?php echo base_url("logout"); ?>">Sair</a>
<?php
} else {
?>
  <a class="btn btn-primary" href="<?php echo base_url("registration"); ?>">Cadastrar</a>
<?php
}
?>
      </div>
    </nav>
  </div>

