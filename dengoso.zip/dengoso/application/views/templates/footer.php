    <script src="<?php echo base_url("assets/js/jquery.js");?>"></script>
    <script src="<?php echo base_url("assets/js/popper.js");?>"></script>
    <script src="<?php echo base_url("assets/js/bootstrap.min.js");?>"></script>
    <!--<script src="<?php echo base_url("assets/js/list.js");?>"></script> -->
    <script src="<?php echo base_url("assets/js/dengoso.js");?>"></script>
  </body>
</html>
