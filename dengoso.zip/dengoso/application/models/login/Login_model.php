<?php
Class Login_model extends CI_Model {
  public function __construct() {
    $this->load->database();
  }
  
  // Insere um novo usuário no DB
  public function registration_insert($data) {
    // Primeiro, checamos se o usuário já existe
    $condition = "email =" . "'" . $data['email'] . "'";
    $this->db->select('*');
    $this->db->from('Usuarios');
    $this->db->where($condition);
    $this->db->limit(1);
    $query = $this->db->get();
    if ($query->num_rows() == 0) {
    // Se não existe, nós inserimos os dados
      $this->db->insert('Usuarios', $data);
      if ($this->db->affected_rows() > 0) {
        return TRUE;
      }
    } else {
      return FALSE;
    }
  }
  // Ler os dados de um usuário
  public function login($data) {
    /*var_dump($data);*/

    $condition = "email =" . "'" . $data['email'] . "' AND " . "senha =" . "'" . $data['senha'] . "'";
    $this->db->select('*');
    $this->db->from('Usuarios');
    $this->db->where($condition);
    $this->db->limit(1);
    $query = $this->db->get();
    if ($query->num_rows() == 1) {
      return true;
    } else {
      return false;
    }
  }
  // Ler os dados para mostrar na barra superior
  public function read_user_information($email) {
    $condition = "email =" . "'" . $email . "'";
    $this->db->select('*');
    $this->db->from('Usuarios');
    $this->db->where($condition);
    $this->db->limit(1);
    $query = $this->db->get();
    if ($query->num_rows() == 1) {
      return $query->result();
    } else {
      return false;
    }
  }
}
?>
