<?php


 class Equipamentos_model extends CI_Model{
	public function __construct() {
			$this->load->database();
	} 
	public function getEquipamentos() {
		 $query = $this->db->get("Equipamentos");
		 	if ($query->num_rows() >= 1) {
      return $query->result_array();
    } else {
      return false;
    
	}
	}	
}   
   
	public function getEquipamentos() {
 	$this->db->select('inventario,nome,descricao');
       $this->db->from('Equipamentos');
       $query = $this->db->get();
 			 if ($query->num_rows() >= 1) {
 			 	$res = $query->result_array();
 			 	foreach ($res as $r) {
 			 		$list [$r['inventario']]=['nome'=>$r['nome'],'descricao'=>$r['descricao']];}
      return $list;
      
    } else {
      return false;
 	}
	
	public function getEquipamentos(){
        $query = $this->db->get('equipamentos');
        return $query->result();
    }
}
