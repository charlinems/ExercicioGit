<?php



class Equipamentos extends CI_Controller{

  public function __construct() {
    parent::__construct();
    // Carregando funções auxiliares de URL
    $this->load->helper('url');
    $this->load->library('session');
    $this->load->model('login/Login_model');
	$this->load->model('equipamentos/Equipamentos_model');
  }
  public function index() {
	
	$data['equipamentos'] = $this->Equipamentos_model->get_equipamentos();
	
	$data['appname'] = "Dengoso - Equipamentos";
    $this->load->view('templates/header', $data);
    $this->load->view('equipamentos/index', $data);
    $this->load->view('templates/footer');
	$this->load->view('pages/equipamentos', $data);
	
  }
}
