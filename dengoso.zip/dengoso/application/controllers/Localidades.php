<?php

Class Localidades extends CI_Controller{

  public function __construct() {
    parent::__construct();
    // Carregando funções auxiliares de URL
    $this->load->helper('url');
    $this->load->library('session');
    $this->load->model('login/Login_model');
  }
  public function index() {
  	$data['appname'] = "Dengoso - Localidades";
    $this->load->view('templates/header', $data);
    $this->load->view('localidades/index', $data);
    $this->load->view('templates/footer');  
	$this->load->view('pages/localidades', $data);

  }
}

