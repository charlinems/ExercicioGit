<?php
if (!isset($this->session->userdata['logged_in'])) {
  header("location: ".base_url());
}

 
class Inserir_produto extends CI_Controller {
 
        public function __construct() {
            parent::__construct();
        }
 
 
	public function index(){
            $dados = array();
            $this->load->model('Equipamentos_model', '', TRUE);
 
            if($this->input->post('acao') == 'inserir'){
                $this->Equipamneto_model->inventario = $this->input->post('inventario');
				$this->Equipamnento_model->nome = $this->input->post('nome');
				$this->Equipamento_model->descricao = $this->input->post('descricao');

                
				
                if($this->Equipamento_model->inserir()){
                    $data['msg'] = 'Produto inserido com sucesso!';
                }
                else{
                    $data['msg'] = 'Erro ao inserir produto.';
                }
            }
 
            $this->load->view('inserir', $dados);
	}
}