<?php

Class Dashboard extends CI_Controller{

  public function __construct() {
    parent::__construct();
    // Carregando funções auxiliares de URL
    $this->load->helper('url');
    $this->load->library('session');
    $this->load->model('login/Login_model');
  }
  // Chama a view com a página de login
  public function index() {
  	$data['appname'] = "Dengoso - Dashboard";
    $this->load->view('templates/header', $data);
    $this->load->view('dashboard/index', $data);
    $this->load->view('templates/footer'); 
	$this->load->view('pages/dashboard', $data);


  }
}
