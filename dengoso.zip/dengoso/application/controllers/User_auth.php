<?php
Class User_auth extends CI_Controller {
  public function __construct() {
    parent::__construct();
    // Carregando funções auxiliares de URL
    $this->load->helper('url');
    // Carregando funções auxiliares de formulário
    $this->load->helper('form');
    // Carregando biblioteca de validação
    $this->load->library('form_validation');
    // Carregando biblioteca de sessão
    $this->load->library('session');
    // Carregando modelo de dados
    $this->load->model('login/Login_model');
  }
  // Chama a view com a página de login
  public function index() {
	$data['appname'] = "Dengoso - Login";
    $this->load->view('templates/header', $data);
	$this->load->view('login/login_form');
	$this->load->view('templates/footer');

  }
  // Mostra a página de registro de usuário
  public function user_registration_show() {
    $data['appname'] = "Dengoso - Cadastro";
    $this->load->view('templates/header', $data);
	$this->load->view('login/registration_form');
	$this->load->view('templates/footer');

  }
  // Validação e registro de novo usuário
  public function new_user_registration() {
    // Regras de validação do formulário de registro
    $this->form_validation->set_rules('username', 'Nome de usuário', 'trim|required');
    $this->form_validation->set_rules('email', 'E-mail', 'trim|required');
    $this->form_validation->set_rules('password', 'Senha', 'trim|required');
    if ($this->form_validation->run() === FALSE) {
      $this->load->view('login/registration_form');
    } else {
      $data = array(
      'nome' => $this->input->post('username'),
      'email' => $this->input->post('email'),
      'senha' => hash('sha512', $this->input->post('password'))
      );
      $result = $this->Login_model->registration_insert($data);
      if ($result === TRUE) {
        $data['message_display'] = 'Registro efetuado com sucesso!';
        $this->load->view('login/login_form', $data);
      } else {
        $data['message_display'] = 'Usuário já cadastrado!';
        $this->load->view('login/registration_form', $data);
      }
    }
  }
  // Processo de login de usuário
  public function user_login_process() {
    $this->form_validation->set_rules('email', 'E-mail', 'trim|required');
    $this->form_validation->set_rules('password', 'Senha', 'trim|required');
    if ($this->form_validation->run() === FALSE) {
      if(isset($this->session->userdata['logged_in'])){
        redirect('Dashboard');
      }else{
        $this->load->view('login/login_form');
      }
    } else {
      $data = array(
      'email' => $this->input->post('email'),
      'senha' => hash('sha512', $this->input->post('password'))
      );
      $result = $this->Login_model->login($data);
      if ($result === TRUE) {
        $email = $this->input->post('email');
        $result = $this->Login_model->read_user_information($email);
        if ($result != FALSE) {
          $session_data = array(
          'username' => $result[0]->nome,
          'email' => $result[0]->email,
          );
          // Add user data in session
          $this->session->set_userdata('logged_in', $session_data);
          redirect('Dashboard');
        }
      } else {
      $data = array(
      'error_message' => 'E-mail ou senha inválidos!'
      );
      $this->load->view('login/login_form', $data);
      }
    }
  }
  // Logout
  public function logout() {
    // Removendo dados de sessão
    $sess_array = array(
    'username' => ''
    );
    $this->session->unset_userdata('logged_in', $sess_array);
    $data['message_display'] = 'Logout completo.';
    $this->load->view('login/login_form', $data);
  }
}
?>
