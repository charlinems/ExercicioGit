<?php

Class Colaboradores extends CI_Controller{

  public function __construct() {
    parent::__construct();
    // Carregando funções auxiliares de URL
    $this->load->helper('url');
    $this->load->library('session');
    $this->load->model('login/Login_model');
  }
  
  public function index() {
  	$data['appname'] = "Dengoso - Colaboradores";
    $this->load->view('templates/header', $data);
    $this->load->view('colaboradores/index', $data);
    $this->load->view('templates/footer'); 
	$this->load->view('pages/colaboradores', $data);
	
  }
}
