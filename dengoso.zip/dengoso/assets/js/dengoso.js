



$(document).ready(function(){
	//get current URL path and assign 'active' class
	let pathname = (window.location.pathname).split('/')[3];
	if(pathname == undefined)
		pathname = (window.location.pathname).split('/')[2];
	let link = $('.nav-item > a[href*="'+pathname+'"]');
	link.parent().addClass('active');
})







